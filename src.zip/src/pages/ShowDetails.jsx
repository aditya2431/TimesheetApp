import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Footer, Navbar } from "../components";
const ShowDetails = () => {

  const [apiResponse, setApiResponse] = useState([]);
  const [wbsElement, setWbsElement] = useState('');
  const location = useLocation();
  console.log(location);

  useEffect(() => {
    fetchData()
  }, []);

  const fetchData = () => {
    fetch("http://localhost:8080/abhi_timesheet/api/timesheet")
      .then(response => {
        return response.json()
      })
      .then(data => {
        setApiResponse(data)
      })
  };

  const handleSubmitButtonClick = () => {
    if (wbsElement) {
      var newArray = apiResponse.filter(obj => obj.wbsCode === wbsElement);
      setApiResponse(newArray);
      setWbsElement('');
    }
  };

  return (
    <>
      <Navbar />
      <div className="container my-3 py-3">
        <h2 className="text-center">Timesheet Records</h2>
        <hr />
        <div className="text-center py-4">
          {apiResponse.length > 0 && (
            <table border={1}>
              <tr>
                <td><b>ID</b></td>
                <td><b>User Name</b></td>
                <td><b>Email Id</b></td>
                <td><b>Category</b></td>
                <td><b>WBS Code</b></td>
                <td><b>Booking Date</b></td>
                <td><b>Booked Efforts</b></td>
                <td><b>Comments</b></td>
              </tr>
              {apiResponse.map(user => (
                <tr>
                  <td>{user.id}</td>
                  <td>{user.userName}</td>
                  <td>{user.emailId}</td>
                  <td>{user.category}</td>
                  <td>{user.wbsCode}</td>
                  <td>{user.createdAt}</td>
                  <td>{user.bookedEfforts}</td>
                  <td>{user.comments}</td>
                </tr>
              ))}
            </table>
          )}
        </div>

        <h2 className="text-center py-4">Filter by WBS Code</h2>
        <div className="text-center py-4">
          <input
            type="text"
            required
            value={wbsElement}
            onChange={(e) => setWbsElement(e.target.value)}
          />
          <button  type='submit' onClick={handleSubmitButtonClick} >SUBMIT</button>
        </div>
      </div>
      <Footer />
    </>
  )
}

export default ShowDetails