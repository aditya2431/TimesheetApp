export { default as Home } from './Home';
export { default as AddNewRecord } from './AddNewRecord';
export { default as ShowDetails } from './ShowDetails';
export { default as ContactPage } from './ContactPage';
export { default as Login } from './Login';
export { default as Register } from './Register';
export { default as PageNotFound } from './PageNotFound';